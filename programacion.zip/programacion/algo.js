import chalk from "chalk";

console.log(chalk.blue("hola mundo"));